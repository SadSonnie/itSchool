// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.stereotype;

import com.intellij.jam.model.util.JamCommonUtil;
import com.intellij.openapi.module.Module;
import com.intellij.psi.PsiAnchor;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.spring.model.jam.utils.JamAnnotationTypeUtil;
import com.intellij.util.NullableFunction;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;

public abstract class SpringMetaStereotypeComponent extends SpringStereotypeElement {

  private static final NullableFunction<PsiClass, String> PSI_CLASS_FQN = PsiClass::getQualifiedName;

  @Nullable private final String myAnno;
  private final PsiAnchor myPsiClassAnchor;

  public SpringMetaStereotypeComponent(@Nullable String anno, @NotNull PsiClass psiClassAnchor) {
    super(anno);

    myAnno = anno;
    myPsiClassAnchor = PsiAnchor.create(psiClassAnchor);
  }

  /**
   * Defining annotation class.
   */
  @Nullable
  public String getDefiningAnnotation() {
    return myAnno;
  }

  protected static Collection<String> getAnnotations(@Nullable Module module,
                                                     @NotNull String annotation) {
    if (module == null || module.isDisposed()) {
      return Collections.singleton(annotation);
    }

    final Collection<PsiClass> classes = JamAnnotationTypeUtil.getInstance(module).getAnnotationTypesWithChildrenIncludingTests(annotation);
    return ContainerUtil.mapNotNull(classes, PSI_CLASS_FQN);
  }

  @Override
  @NotNull
  public PsiClass getPsiElement() {
    return (PsiClass)JamCommonUtil.retrieveOrThrow(myPsiClassAnchor);
  }

  @Override
  public boolean isValid() {
    PsiElement psiElement = myPsiClassAnchor.retrieve();
    return psiElement != null && psiElement.isValid();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof SpringMetaStereotypeComponent)) return false;

    SpringMetaStereotypeComponent that = (SpringMetaStereotypeComponent)o;

    if (myAnno != null ? !myAnno.equals(that.myAnno) : that.myAnno != null) return false;
    if (myPsiClassAnchor != null ? !myPsiClassAnchor.equals(that.myPsiClassAnchor) : that.myPsiClassAnchor != null) return false;

    return true;
  }

  @Override
  public int hashCode() {
    int result = myAnno != null ? myAnno.hashCode() : 0;
    result = 31 * result + (myPsiClassAnchor != null ? myPsiClassAnchor.hashCode() : 0);
    return result;
  }
}