package com.intellij.psi.css;

import com.intellij.psi.NavigatablePsiElement;
import com.intellij.psi.PsiNameIdentifierOwner;

public interface CssValueImportedAlias extends CssNamedElement, NavigatablePsiElement, PsiNameIdentifierOwner {
}
