package com.intellij.psi.css.resolve;

import com.intellij.psi.css.CssSelector;
import com.intellij.psi.xml.XmlTag;
import org.jetbrains.annotations.NotNull;

/**
 * @author Eugene.Kudelevsky
 */
public interface CssSelectorMatcher {
  boolean isMatch(@NotNull CssSelector selector, @NotNull XmlTag tag, @NotNull CssResolver resolver);
}
