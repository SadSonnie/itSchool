package com.intellij.psi.css;

import com.intellij.psi.css.descriptor.CssValueOwnerDescriptor;
import org.jetbrains.annotations.Nullable;

public interface CssMediaFeatureDescriptor extends CssValueOwnerDescriptor, CssMediaGroupAwareDescriptor {
  @Nullable
  String getAppliesToValue();
}
