package com.intellij.psi.css;

import com.intellij.navigation.NavigationItem;
import com.intellij.psi.css.descriptor.CssContextType;
import org.jetbrains.annotations.NotNull;

public interface CssAtRule extends CssElement, NavigationItem {
  CssAtRule[] EMPTY_ARRAY = new CssAtRule[0];

  @Override
  @NotNull
  String getName();

  @NotNull
  CssContextType getType();
}
