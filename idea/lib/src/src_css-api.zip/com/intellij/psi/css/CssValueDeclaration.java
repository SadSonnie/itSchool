package com.intellij.psi.css;

import com.intellij.psi.NavigatablePsiElement;
import com.intellij.psi.PsiNameIdentifierOwner;
import org.jetbrains.annotations.Nullable;

public interface CssValueDeclaration extends CssNamedElement, NavigatablePsiElement, PsiNameIdentifierOwner {
  @Nullable
  String getValueValueText();
}
