package com.intellij.javaee.deployment;

import java.util.List;

public interface DeploymentView {

  List<DeploymentModel> getSelectedModels();
}
