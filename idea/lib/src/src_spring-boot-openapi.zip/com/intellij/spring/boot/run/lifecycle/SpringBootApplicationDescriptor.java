// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.run.lifecycle;

import com.intellij.execution.configurations.RunProfile;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.openapi.module.Module;
import org.jetbrains.annotations.NotNull;

public interface SpringBootApplicationDescriptor {
  @NotNull
  ProcessHandler getProcessHandler();

  @NotNull
  RunProfile getRunProfile();

  @NotNull
  String getExecutorId();

  @NotNull
  Module getModule();
}
