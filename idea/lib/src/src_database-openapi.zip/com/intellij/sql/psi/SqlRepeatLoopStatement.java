package com.intellij.sql.psi;

public interface SqlRepeatLoopStatement extends SqlConditionalLoopStatement {
}