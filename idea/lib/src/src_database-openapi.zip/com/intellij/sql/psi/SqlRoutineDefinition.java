package com.intellij.sql.psi;

import com.intellij.database.model.DasRoutine;

public interface SqlRoutineDefinition extends SqlDefinition, SqlControlFlowHolder, DasRoutine {

}
