package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlCreateCharacterSetStatement extends SqlCreateStatement {
}
