package org.jetbrains.idea.tomcat.descriptor;

import com.intellij.javaee.oss.descriptor.JavaeeDescriptorsProviderBase;
import com.intellij.javaee.oss.server.JavaeeIntegration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.idea.tomcat.server.TomcatIntegration;

final class TomcatDescriptorsProvider extends JavaeeDescriptorsProviderBase {
  @NotNull
  @Override
  protected JavaeeIntegration getIntegration() {
    return TomcatIntegration.getInstance();
  }
}
