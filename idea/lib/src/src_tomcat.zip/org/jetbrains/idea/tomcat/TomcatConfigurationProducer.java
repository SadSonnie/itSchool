package org.jetbrains.idea.tomcat;

import com.intellij.javaee.run.configuration.J2EEConfigurationProducer;
import org.jetbrains.idea.tomcat.server.TomcatConfiguration;

final class TomcatConfigurationProducer extends J2EEConfigurationProducer {
  TomcatConfigurationProducer() {
    super(TomcatConfiguration.getInstance());
  }
}
